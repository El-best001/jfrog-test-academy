from email.policy import default
from sqlalchemy import Boolean, Column, ForeignKey, Integer, String,DateTime
from database import Base
from sqlalchemy.orm import relationship
from passlib.context import CryptContext
import datetime

class Users(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String,unique=True,index=True)
    username = Column(String,unique=True, index=True)
    first_name = Column(String)
    last_name = Column(String)
    hashed_password = Column(String)
    is_active = Column(Boolean,default=True)

    repository = relationship("Repository", back_populates="user")


class Repository(Base):
    __tablename__  = "repository"

    id  = Column(Integer,primary_key=True,index=True)
    name   = Column(String)
    description   = Column(String)
    created_date = Column(DateTime, default=datetime.datetime.utcnow)
    user_id = Column(Integer,ForeignKey("users.id"))
    user = relationship("Users",back_populates="repository")
