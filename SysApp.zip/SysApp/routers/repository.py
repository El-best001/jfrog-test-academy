from typing import Optional
from fastapi import Depends, HTTPException,APIRouter
import models
from database import engine,SessionLocal
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
from routers.auth import get_current_user, get_user_exception
import platform
import os

from routers import auth

router = APIRouter(
    tags=["repository"],
    responses={404: {"description":"Not found"}}
)

models.Base.metadata.create_all(bind=engine)


def get_db():
    try:
        db = SessionLocal()
        yield db
    finally:
        db.close()


class Repository(BaseModel):
    name: str
    description: Optional[str]


@router.post("/create/repo")
async def create_repository(repository:Repository, user: dict = Depends(get_current_user), db: Session= Depends(get_db)):

    if user is None:
        raise get_user_exception()
    
    repository_model = models.Repository()
    repository_model.name = repository.name
    repository_model.description = repository.description
    repository_model.user_id  = user.get("id")

    initial_path = f"./Repositories/{user.get('username')}"
    try:
        os.mkdir(initial_path)
        os.mkdir(f"{initial_path}/{repository.name}")
    except OSError as error:
        try:
            os.mkdir(f"{initial_path}/{repository.name}")
        except OSError as error:
            return {"Error":f'{error}'}

    # "add" method places an object in the session, its state will be persisted to the database on the next flush operation
    db.add(repository_model)

    # to flush it
    db.commit()

    return successful_response(201)

@router.get("/list/repo")
async def list_repository(user: dict = Depends(get_current_user), db: Session= Depends(get_db)):

    if user is None:
        raise get_user_exception()
    return db.query(models.Repository).filter(models.Repository.user_id == user.get("id")).all()


@router.get("/sys/version")
async def system_version(user: dict = Depends(get_current_user),token:dict = Depends(get_current_user)):

        if user is None:
            raise get_user_exception()
        else:
            return {'Release Version': platform.version(),'System Version': platform.system()}


    
def successful_response(status_code: int):
    return {'status': status_code,'transaction': 'Successful'}

def http_exception():
    return HTTPException(status_code=404, detail="Todo not found")
