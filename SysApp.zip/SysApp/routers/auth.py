import sys

# When rendered, jump to the parent directory, so that when can get dependent modules for this module
sys.path.append("..")
from fastapi import Depends,status, APIRouter
from pydantic import BaseModel
from typing import Optional
import models
from passlib.context import CryptContext
from sqlalchemy.orm import Session
from database import SessionLocal,engine
from fastapi.security import OAuth2PasswordRequestForm,OAuth2PasswordBearer
from fastapi import HTTPException
from datetime import datetime, timedelta
from jose import jwt,JWTError
from sqlalchemy.exc import IntegrityError as AlchemyIntegrityError
import shutil


SECRET_KEY = "WKU98ie&*EWFT*(_$#9903JDI*7^$989%$Jz"

ALGORITHM = "HS256"

class CreateUser(BaseModel):
    username:str
    email: Optional[str]
    first_name:str
    last_name:str
    password:str

bcrypt_context = CryptContext(schemes=["bcrypt"],deprecated="auto")

models.Base.metadata.create_all(bind=engine)

oauth2_bearer = OAuth2PasswordBearer(tokenUrl="token")



router = APIRouter(
    prefix="/auth",
    tags=["auth"],
    responses={401:{"user":"Not authorized"}}
)

def get_db():
    try:
        db = SessionLocal()
        yield db
    finally:
        db.close()

def get_password_hash(password):
    return bcrypt_context.hash(password)

def verify_password(plain_password, hashed_password):
    return bcrypt_context.verify(plain_password, hashed_password)

def authenticate_user(username: str, password: str, db):
    user = db.query(models.Users)\
    .filter(models.Users.username ==username)\
    .first()

    if not user:
        return False
    if not verify_password(password,user.hashed_password):
        return False
    return user

def create_access_token(username: str, user_id: int, expires_delta: Optional[timedelta] = None):
    encode = {"sub":username, "id":user_id}
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    encode.update({"exp":expire})
    return jwt.encode(encode,SECRET_KEY,algorithm=ALGORITHM)


@router.post("/create/user")
async def create_new_user(create_user:CreateUser, db:Session = Depends(get_db)):
    create_user_model = models.Users()
    create_user_model.email = create_user.email
    create_user_model.username = create_user.username
    create_user_model.first_name = create_user.first_name
    create_user_model.last_name = create_user.last_name
    hash_password = get_password_hash(create_user.password)
    create_user_model.hashed_password = hash_password
    create_user_model.is_active = True

    try:
        db.add(create_user_model)
        db.commit()
        msg =f'User created succesfully'
        return successful_response(200,msg)
    except AlchemyIntegrityError as error:
        return{"message":"Duplicate records"}


@router.post("/token")
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends(),
                                db: Session = Depends(get_db)):
    user = authenticate_user(form_data.username, form_data.password,db)

    if not user:
        # raise HTTPException(status_code=404, detail="User not found")
        raise token_exception()
    token_expires = timedelta(minutes=262800) # 6 months
    token = create_access_token(user.username,
                                user.id,
                                expires_delta=token_expires)

    return {"token":token}


async def get_current_user(token: str = Depends(oauth2_bearer)):
    try:
        payload = jwt.decode(token,SECRET_KEY,algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        user_id: int = payload.get("id")
        if username is None or user_id is None:
            # raise HTTPException(status_code=404, detail="User not found")
            raise get_user_exception()
        return {"username":username,"id":user_id}
    except JWTError:
        # raise HTTPException(status_code=404,detail="User not found")
        raise get_user_exception()

#Exceptions
def get_user_exception():
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    return credentials_exception

def token_exception():
    token_exception_reponse = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Incorrect username or password",
        headers={"WWA-Authenticate":"Bearer"},
    )
    return token_exception_reponse


@router.delete("/delete/{user_id}")
async def delete_user(user_id: int, 
                        user: dict = Depends(get_current_user),
                        db: Session = Depends(get_db)):
    if user is None:
        raise get_user_exception()

    
    objects = models.Users
    repo_objects = models.Repository

    user_model = db.query(objects)\
                .filter(objects.id == user_id).first()

    if user_model is None:
        raise http_exception()

    path =f"./repositories/{user.get('username')}"
    try:
        # delete repo and its contents
        shutil.rmtree(path)
    except OSError as e:
        pass

    db.query(objects).filter(objects.id == user_id).delete()
    db.query(repo_objects).filter(repo_objects.id == user_id).delete()

    db.commit()
    return successful_response(200,"User deleted succesfully")


def successful_response(status_code: int,message=None):
    if(message == None):
        return {'status': status_code,'transaction': 'Successful'}
    else:
        return {'status': status_code,'transaction': 'Successful','message':message}


def http_exception():
    return HTTPException(status_code=404, detail="User not found")