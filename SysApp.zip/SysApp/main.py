
from fastapi import FastAPI, Depends
import models
from database import engine

from routers import auth,repository

app = FastAPI()

models.Base.metadata.create_all(bind=engine)

@app.get("/")
async def root():
    return {"Message": "Welcome to my FastAPI!",}

app.include_router(auth.router)
app.include_router(repository.router)